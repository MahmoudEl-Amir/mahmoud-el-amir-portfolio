# Mahmoud El-Amir — Portfolio

Static portfolio built from the supplied CV.

## Run locally
Open `index.html` in a browser.

## Deploy free
- Vercel: import this folder/repository.
- GitHub Pages: push the files to a GitHub repository and enable Pages.

## Replace/add later
- Project GitHub/demo links
- Profile photo (optional)
- Downloadable CV PDF
